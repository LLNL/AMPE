        TMW_ROOT="$MATLAB"
        MFLAGS=''
        if [ "$ENTRYPOINT" = "mexLibrary" ]; then
            MLIBS="-L$TMW_ROOT/bin/$Arch -lmx -lmex -lmatlb -lmat -lmwservices -lut -lm"
        else  
            MLIBS="-L$TMW_ROOT/bin/$Arch -lmx -lmex -lmat -lm"
        fi

        RPATH="-Wl,--rpath-link,$TMW_ROOT/extern/lib/$Arch,--rpath-link,$TMW_ROOT/bin/$Arch"
        CC='gcc'
        CFLAGS='-fPIC -ansi -D_GNU_SOURCE -pthread'
        CLIBS="$RPATH $MLIBS -lm"
        COPTIMFLAGS='-O -DNDEBUG'
        CDEBUGFLAGS='-g'
#
        CXX='g++'
        CXXFLAGS='-fPIC -ansi -pthread'
        CXXLIBS="$RPATH $MLIBS -lm"
        CXXOPTIMFLAGS='-O -DNDEBUG'
        CXXDEBUGFLAGS='-g'
#
        LD="$COMPILER"
        LDFLAGS="-pthread -shared -Wl,--version-script,$TMW_ROOT/extern/lib/$Arch/$MAPFILE"
        LDOPTIMFLAGS='-O'
        LDDEBUGFLAGS='-g'
#
        POSTLINK_CMDS=':'
