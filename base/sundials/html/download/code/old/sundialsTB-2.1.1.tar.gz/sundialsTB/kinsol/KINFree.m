function [] = KINFree()
%KINFree deallocates memory for the KINSOL solver.
%
%   Usage:  KINFree
%

% Radu Serban <radu@llnl.gov>
% Copyright (c) 2005, The Regents of the University of California.
% Produced at the Lawrence Livermore National Laboratory
% All rights reserved.
% For details, see sundialsTB/LICENSE.
% $Revision$Date$

mode = 6;
kim(mode);
