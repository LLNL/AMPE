function [] = CVodeFree()
%CVodeFree deallocates memory for the CVODES solver.
%
%   Usage:  CVodeFree

% Radu Serban <radu@llnl.gov>
% Copyright (c) 2005, The Regents of the University of California.
% Produced at the Lawrence Livermore National Laboratory
% All rights reserved.
% For details, see sundialsTB/LICENSE.
% $Revision$Date$

mode = 11;
cvm(mode);
